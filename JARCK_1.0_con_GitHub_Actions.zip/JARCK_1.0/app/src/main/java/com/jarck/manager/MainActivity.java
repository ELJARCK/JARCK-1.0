package com.jarck.manager;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16,24,32);
    private final int PANEL = Color.rgb(27,39,49);
    private final int GREEN = Color.rgb(124,255,0);
    private EditText codesInput;
    private ListView listView;
    private ArrayList<String> codes = new ArrayList<>();
    private ArrayList<String> statuses = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private int selected = -1;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("jarck", MODE_PRIVATE);
        buildUi();
        codesInput.setText(prefs.getString("codes", ""));
        loadStatuses();
        refreshList();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.BLACK);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));
        return b;
    }

    private void buildUi() {
        LinearLayout root = column();
        root.setPadding(18, 22, 18, 14);
        root.setBackgroundColor(BG);

        TextView title = text("JARCK 1.0", 30, GREEN, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1, -2));
        TextView sub = text("XBOX CODE MANAGER", 12, Color.WHITE, true);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, lp(-1, -2));

        TextView hint = text("Pega tus códigos (uno por renglón). Se guardan en este dispositivo.", 14, Color.LTGRAY, false);
        hint.setPadding(0, 18, 0, 8);
        root.addView(hint);

        codesInput = new EditText(this);
        codesInput.setHint("XXXXX-XXXXX-XXXXX-XXXXX-XXXXX");
        codesInput.setTextColor(Color.WHITE);
        codesInput.setHintTextColor(Color.GRAY);
        codesInput.setGravity(Gravity.TOP | Gravity.START);
        codesInput.setMinLines(3);
        codesInput.setMaxLines(6);
        codesInput.setPadding(12, 10, 12, 10);
        codesInput.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));
        root.addView(codesInput, lp(-1, -2));

        Button save = button("Guardar / actualizar lista");
        save.setOnClickListener(v -> { saveCodes(); refreshList(); toast("Lista guardada"); });
        root.addView(save, lp(-1, -2));

        TextView label = text("Toca un renglón para seleccionarlo:", 14, Color.WHITE, true);
        label.setPadding(0, 14, 0, 6);
        root.addView(label);

        listView = new ListView(this);
        listView.setBackgroundColor(PANEL);
        root.addView(listView, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = button("Copiar");
        Button status = button("Cambiar estado");
        actions.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        actions.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(actions);
        copy.setOnClickListener(v -> copySelected());
        status.setOnClickListener(v -> cycleStatus());

        Button redeem = button("Abrir canje oficial de Microsoft");
        redeem.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://redeem.microsoft.com/"));
            startActivity(i);
        });
        root.addView(redeem, lp(-1, -2));

        TextView foot = text("JARCK organiza tus códigos; no verifica ni canjea códigos automáticamente.", 11, Color.LTGRAY, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, 8, 0, 0);
        root.addView(foot);
        setContentView(root);
    }

    private void saveCodes() {
        prefs.edit().putString("codes", codesInput.getText().toString()).apply();
        Set<String> old = prefs.getStringSet("statuses", new HashSet<>());
        // Preserve saved status records; new rows default to Pendiente.
        loadStatuses();
    }

    private void loadStatuses() {
        statuses.clear();
        String raw = prefs.getString("status_list", "");
        if (!raw.isEmpty()) {
            String[] parts = raw.split("\\n", -1);
            for (String p : parts) statuses.add(p);
        }
    }

    private void persistStatuses() {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < statuses.size(); i++) {
            if (i > 0) b.append('\n');
            b.append(statuses.get(i));
        }
        prefs.edit().putString("status_list", b.toString()).apply();
    }

    private void refreshList() {
        String raw = codesInput.getText().toString();
        String[] lines = raw.split("\\r?\\n");
        codes.clear();
        for (String line : lines) {
            String c = line.trim();
            if (!c.isEmpty() && !codes.contains(c)) codes.add(c);
        }
        while (statuses.size() < codes.size()) statuses.add("Pendiente");
        while (statuses.size() > codes.size()) statuses.remove(statuses.size() - 1);
        persistStatuses();
        ArrayList<String> rows = new ArrayList<>();
        for (int i = 0; i < codes.size(); i++) {
            String mark = (i == selected) ? "▶ " : "   ";
            rows.add(mark + (i + 1) + ". " + codes.get(i) + "   [" + statuses.get(i) + "]");
        }
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, rows) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(Color.WHITE); v.setTextSize(13); v.setPadding(12, 12, 8, 12);
                v.setBackgroundColor(position == selected ? Color.rgb(48,68,45) : PANEL);
                return v;
            }
        };
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((p, v, pos, id) -> { selected = pos; refreshList(); });
    }

    private void copySelected() {
        if (selected < 0 || selected >= codes.size()) { toast("Primero selecciona un renglón"); return; }
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Código", codes.get(selected)));
        toast("Código copiado");
    }

    private void cycleStatus() {
        if (selected < 0 || selected >= statuses.size()) { toast("Primero selecciona un renglón"); return; }
        String s = statuses.get(selected);
        statuses.set(selected, s.equals("Pendiente") ? "Revisado" : s.equals("Revisado") ? "Canjeado" : "Pendiente");
        persistStatuses(); refreshList();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
